
package Rgstrn;

import java.util.Scanner;


public class Rgstrn {
    static String password;
    static String firstName;
    static String surname;
    static String userName;

        
    public static void setFirstName(String name){               
        userName = name;
    }
    public static String getFirstName(){
        return firstName;
    }
    public static void setUserName(String name){               
        userName = name;
    }
    public static String getUserName(){
        return userName;
    }
    //set and get the password
    public static void setPassword(String pass){
        password = pass;
    }
    public static String getPassword(){
        return password;
    }
    
    //set and get the user's surname
    public static void setSurname(String srname){
        surname = srname;
    }
    public static String getSurname(){
        return surname;
        
    }

    public static void userDetails(){
        Scanner inforA = new Scanner(System.in);
        
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your name");
        firstName = input.nextLine();
        System.out.println("Enter your surname");
        surname = input.nextLine();
        System.out.println("Enter your password");
        password = input.nextLine();
        System.out.println("Enter your user name");
        userName = input.nextLine();
    }
         
     public static void main(String[] args) {
        userDetails();
        Login logObject = new Login();
        
        logObject.checkUserName();
        logObject.registerUser();
        System.out.println(logObject.returnLoginStatus());
        
    }
    

    }
    
    

