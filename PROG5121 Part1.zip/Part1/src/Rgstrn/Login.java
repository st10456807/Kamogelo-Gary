
package Rgstrn;

import java.util.Scanner;


public class Login {
   
    public boolean checkUserName(){
        return Rgstrn.userName.contains("_") && Rgstrn.userName.length()<=5;
        }
   
    
    public boolean checkPasswordComplexity(){
        
    boolean passwordStatus = false;
    boolean length = false;
    boolean number = false;
    boolean specialCharacter = false;
    boolean upperCase = false;
    char ch;
    
    if(Rgstrn.password.length() >= 8){
        length = true;
    }
    for(int i =0; i < Rgstrn.password.length(); i = i+1 ){
        ch = Rgstrn.password.charAt(i);
        
        if(Character.isDigit(ch)){
            number = true;
        }
        if(Character.isUpperCase(ch)){
            upperCase = true;
        }
        if(!Character.isLetterOrDigit(ch)){
             specialCharacter = true;
        }
    passwordStatus = specialCharacter && number && length && upperCase;
    }
    return passwordStatus;
    }
    
    public void registerUser(){
    if(checkUserName()){
        System.out.println("Username successfully captured");
    }
    else{
        System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in lenght");
    }
    if(checkPasswordComplexity()){
        System.out.println("Password successfully captured");
    }
    else{
        System.out.println("Password is not correctly formatted, please ensure the password contains at least 8 characters, a capital letter, a number and a special character. ");
    }
 }
  
 boolean loginUser(){
    Scanner inforB = new Scanner(System.in);
    
     System.out.println("Enter the user name you used to create an account");
     String username2 = inforB.nextLine();
      System.out.println("Enter the password you used to create an account");
    String password2 = inforB.nextLine();
     
        return Rgstrn.userName.equals(username2)&& Rgstrn.password.equals(password2);
 } 

public String returnLoginStatus(){
    if(loginUser()){
        return "Welcome " + Rgstrn.firstName + " " + Rgstrn.surname + " it is great to see you again.";
    }
    else{
        return "Username or password incorrect, please try again.";
    }
} 

}
